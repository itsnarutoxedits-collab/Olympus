import os

TOKEN = os.environ.get("TOKEN")
NAME = "Olympus"
server = "https://discord.com/invite/odx"
ch = "https://discord.com/channels/699587669059174461/1271825678710476911"
OWNER_IDS = [213347081799073793, 1070619070468214824]
BotName = "Olympus"
serverLink = "https://discord.com/invite/odx"